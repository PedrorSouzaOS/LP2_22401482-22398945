package pt.ulusofona.lp2.greatprogrammingjourney;

import java.util.ArrayList;

public class Tabuleiro {
    int tamanho;
    ArrayList<Player> jogadores;
}
